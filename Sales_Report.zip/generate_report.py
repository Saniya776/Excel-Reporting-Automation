
import pandas as pd
import matplotlib.pyplot as plt

# Read data
df = pd.read_csv("sales_data_100_rows.csv")

# Clean data (optional if already clean)
df.dropna(inplace=True)

# Group by Region
region_sales = df.groupby("Region")["Sales"].sum()

# Group by Product
product_sales = df.groupby("Product")["Sales"].sum()

# Save Excel report
with pd.ExcelWriter("Sales_Report.xlsx") as writer:
    df.to_excel(writer, sheet_name="Raw Data", index=False)
    region_sales.to_excel(writer, sheet_name="Region Sales")
    product_sales.to_excel(writer, sheet_name="Product Sales")

# Save bar chart - Region Sales
region_sales.plot(kind="bar", title="Sales by Region", colormap="viridis")
plt.tight_layout()
plt.savefig("region_sales.png")
plt.close()

# Save bar chart - Product Sales
product_sales.plot(kind="bar", title="Sales by Product", color="teal")
plt.tight_layout()
plt.savefig("product_sales.png")
plt.close()

print("✅ Report generated: Sales_Report.xlsx")
print("📊 Charts saved: region_sales.png, product_sales.png")
